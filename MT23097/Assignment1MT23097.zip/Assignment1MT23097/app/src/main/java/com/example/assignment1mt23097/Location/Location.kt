package com.example.assignment1mt23097.Location

data class Locations(val name:String,val distFromSource:Double,val distFromDest:Double)
